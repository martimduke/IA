package searchalgorithm;

public enum Algorithms {
	BreadthFirstSearch, DepthFirstSearch, UniformCostSearch, GreedySearch, AStarSearch
}

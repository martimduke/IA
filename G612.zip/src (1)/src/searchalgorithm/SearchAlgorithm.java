package searchalgorithm;
import java.util.Map;

public class SearchAlgorithm {
	public Node searchSolution() {
		return null;
	}
	
	public Map<String,Number> getMetrics() {
		return null;
	}
}
